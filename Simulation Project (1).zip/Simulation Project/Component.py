"""
Enum class component models the types of components required to build a product

Authors
Peter Tanyous 101127203
Sara Shikhhassan 101142208
Sam Al Zoubi 101140949

Version 1 February 10, 2023

"""
from enum import Enum;
class Component(Enum):
    C1 = "C1"
    C2 = "C2"
    C3 = "C3"
